# Online-Voting-System-using-php-and-mysql

### Description : 
In "ONLINE VOTING SYSTEM" a voter can use his/her voting right online without any difficulty. He/She has to be registered first for him/her to vote. Registration is mainly done by the system administrator for security reasons. The system Adminstrator registers the voters on a special site of the system visited by him only by simply filling a registration form to register voter.
After registration, the voter is assigned a secret Voter ID with which he/she can use to log into the system and enjoy services provide by the system such as voting. If invalid/wrong details are submitted, then the citizen is not registered to vote.

#### Installation : 

  Create a database `poll`.
  
  import `poll.sql` file from phpmyadmin.

  ```ADMIN LOGIN DETAILS 
  URL: localhost/online_voting/admin 
  Email : admin@gmail.com 
  Password : admin 
  ```
